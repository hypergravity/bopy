__version__ = '0.0.1'

def core_print():
    print 'bopy is coming!'
